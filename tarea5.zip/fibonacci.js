const fibonacci = [];
fibonaccconst fibonacci = [];
fibonacci[0] = 0;
fibonacci[1] = 1;
for (const i = 2; i < 5; i++) {
  fibonacci[i] = fibonacci[i - 2] + fibonacci[i - 1];
}
console.log(fibonacci);i[0] = 0;
fibonacci[1] = 1;
for (const i = 2; i < 5; i++) {
  fibonacci[i] = fibonacci[i - 2] + fibonacci[i - 1];
}
console.log(fibonacci);
