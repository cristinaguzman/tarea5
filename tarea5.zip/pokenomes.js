let nombrepokemon = new Array["Charmanderm", "Charmeleon", "Vulpix", "Ninetales", "Growlithe", "Arcanine", "Ponyta", "Rapidash", "Magmar", "Flareon", "Cyndaquil", "Quilava","Typhlosion", "Slugma", "Magby", "Entei", "Torchic", "Torkoal", "Chimchar", "Magmortar", "Tepig", "Pansear", "Simisear", "Darumaka", "Darmanitan","Heatmor", "Fennekin", "Braixen", "Litten","Torracat", "Scorbunny", "Raboot", "Cinderace"];

nombrepokemon[1];
"Charmeleon"

console.log(nombrepokemon);
