let mayusSplit = split.map(palabra => {
    return palabra[0].toUpperCase() + palabra.slice(1);
})

console.log(mayusSplit);
